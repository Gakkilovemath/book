//
//  main.m
//  compriskMacGui
//
//  Created by Piet on 09-04-15.
//  Copyright (c) 2015 Piet. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
